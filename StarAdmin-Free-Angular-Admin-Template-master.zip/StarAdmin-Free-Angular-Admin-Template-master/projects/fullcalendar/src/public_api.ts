/*
 * Public API Surface of fullcalendar
 */

export * from './lib/fullcalendar.component';
export * from './lib/fullcalendar.module';

// make available all of FC's utils/types
export * from '@fullcalendar/core';
