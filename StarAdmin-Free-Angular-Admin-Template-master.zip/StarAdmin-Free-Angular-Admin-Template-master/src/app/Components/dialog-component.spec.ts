import { DialogComponent } from './dialog-component';

describe('DialogComponent', () => {
  it('should create an instance', () => {
    expect(new DialogComponent()).toBeTruthy();
  });
});
