import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supprimeformateur',
  templateUrl: './supprimeformateur.component.html',
  styleUrls: ['./supprimeformateur.component.scss']
})
export class SupprimeformateurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
