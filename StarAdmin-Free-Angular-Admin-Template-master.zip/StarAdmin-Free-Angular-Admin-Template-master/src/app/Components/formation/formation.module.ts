import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormationRoutingModule } from './formation-routing.module';
import { ListerformationComponent } from './listerformation/listerformation.component';
import { CalendrierformationComponent } from './calendrierformation/calendrierformation.component';
import { FormationComponent } from './formation/formation.component';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { Routes, RouterModule } from '@angular/router';
import { OuvrirsessionComponent } from './ouvrirsession/ouvrirsession.component';
import { ListformationmoduleComponent } from './listformationmodule/listformationmodule.component';
import { ListformationmetiersComponent } from './listformationmetiers/listformationmetiers.component';
import { PromotionComponent } from './promotion/promotion.component';
import { ChoisirpromotionComponent } from './choisirpromotion/choisirpromotion.component';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { ListerprogrammekhdemniComponent } from './listerprogrammekhdemni/listerprogrammekhdemni.component';
@NgModule({
  declarations: [ ListerformationComponent, CalendrierformationComponent, FormationComponent,  OuvrirsessionComponent, ListformationmoduleComponent, ListformationmetiersComponent, PromotionComponent, ChoisirpromotionComponent,  ListerprogrammekhdemniComponent],
  imports: [
    CommonModule,
    FormationRoutingModule ,
    NgbModule ,
    FormsModule,
    ReactiveFormsModule
 ,RouterModule ,NgMultiSelectDropDownModule.forRoot()
  ]
})
export class FormationModule { }
