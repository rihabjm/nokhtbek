import { Router, ActivatedRoute } from '@angular/router';
import {FormationService} from '../../../Service/formation.service';
import {Formation} from '../../../Model/formation';
import {FormationMetiers} from '../../../Model/formation-metiers';
import {FormationMetiersService} from '../../../Service/formation-metiers.service';
import {Formationmodule} from '../../../Model/formationmodule';
import {FormationmoduleService} from '../../../Service/formationmodule.service';
import { Component, OnInit, ViewChild } from '@angular/core';

import { Observable } from 'rxjs/observable';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {NgControl,ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-listformationmetiers',
  templateUrl: './listformationmetiers.component.html',
  styleUrls: ['./listformationmetiers.component.scss']
})
export class ListformationmetiersComponent implements OnInit {
type :String ;
obj : String ;
message :String ;
formations : FormationMetiers[] = new Array();


  constructor(config: NgbModalConfig, private modalService: NgbModal , private router: Router ,private  formationservice : FormationService , private formationsmetiersservice :FormationMetiersService ,private formationmoduleserice: FormationmoduleService)
 { }


  ngOnInit() {
  this.getAllformationsmetiers() ;

  }
private getAllformationsmetiers() {
 this.formationsmetiersservice.getAll().subscribe(data => {
 this.formations=data ;
      console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}
    delete(id: number) {

    this.formationsmetiersservice.delete(id).subscribe(data => {
      if (data.success) {

this.message="Formation supprimer"

      this.getAllformationsmetiers();

} else {
this.message="Erreur de suppresion" ;
  }

    }, ex => {

     console.log(ex);
    });
  }




private getAllformationsBYcategorie(obj : String) {
 this.formationsmetiersservice.getformationBycategorie(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}




private getAllformationsBYintitule(obj : String) {
 this.formationsmetiersservice.getformationBYintitule(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}




private getAllformationsBytype(obj : String) {
 this.formationsmetiersservice.getformationBytype(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}

private getAllformationsByprix(obj : String) {
 this.formationsmetiersservice.getformationByprix(obj).subscribe(data => {
 this.formations=data ;
 console.log(this.formations);
    }, ex => {
      console.log(ex);
    });}



//*************************** ajouter *************** //

  formation:FormationMetiers=new FormationMetiers ;


  openajout(contentajout) {

    this.modalService.open(contentajout);

  }

messageajout :String ;




ajouter(formation:FormationMetiers)
{
this.formationsmetiersservice.save(this.formation).subscribe( data => {
   this.getAllformationsmetiers();
    this.messageajout="Formation metier ajouté" ;

    }, ex => {
    this.messageajout="Echec d'ajout" ;
      console.log(ex);
    });


           }


/**************************** modifier *************************************/

messagemodif :String ;
  formationmod:FormationMetiers=new FormationMetiers ;
openmodif(contentmodif,id : number)

{
    this.modalService.open(contentmodif);
               this.formationsmetiersservice.get(id)
      .subscribe(data => {
        console.log(data)
        this.formationmod = data;
      }, error => console.log(error));

}


  private update(formationmod:FormationMetiers) {
    this.formationsmetiersservice.update(formationmod).subscribe(
data => {
     if (data.success) {

     this.messagemodif ="Formation modifié ";

     } else {
          this.messagemodif ="Echec de modification ";

     }
    }, ex => {console.log(ex);
    });
  }








}
