import{Certificats } from './certificats' ;
import{Utilisateur } from './utilisateur' ;
import{Formation } from './formation' ;
import{Specilaite } from './specilaite' ;
export class Formateur extends Utilisateur {
         Formation  :Formation[]  ;
       certificats  :Certificats[]  ;
       specilaites :Specilaite[];
   cv :String ;


}
