import{Utilisateur } from './utilisateur' ;

export class Inscrir extends Utilisateur {
}
