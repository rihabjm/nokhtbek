
import {Formation} from './formation';
export class ProgrammeKhademni extends Formation {
}
