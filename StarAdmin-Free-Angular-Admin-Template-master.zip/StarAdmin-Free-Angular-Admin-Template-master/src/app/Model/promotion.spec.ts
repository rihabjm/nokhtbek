import { Promotion } from './promotion';

describe('Promotion', () => {
  it('should create an instance', () => {
    expect(new Promotion()).toBeTruthy();
  });
});
