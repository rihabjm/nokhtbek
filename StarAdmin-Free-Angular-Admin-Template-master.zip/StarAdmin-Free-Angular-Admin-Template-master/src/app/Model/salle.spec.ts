import { Salle } from './salle';

describe('Salle', () => {
  it('should create an instance', () => {
    expect(new Salle()).toBeTruthy();
  });
});
