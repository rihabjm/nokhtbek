import { Salle} from './Salle';
export class Seance {
idseance : number ;
heuredeb : string  ;
heurefin :string ;
numeroseance :number ;
salle :Salle ;
}

