import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {FormationMetiers} from '../Model/formation-metiers';
@Injectable({
  providedIn: 'root'
})
export class FormationMetiersService {
  constructor(private httpClient: HttpClient) { }
private url = Config.BASE_URL + '/formationMetiers';
private urldetails = this.url + '/byid';
private urld = this.url + '/products';

  createProduct(product: object, idCategory: number): Observable<any> {
    return this.httpClient.post(`${this.urld}/${idCategory}`, product);
  }





 public save(formationmetiers:FormationMetiers): Observable<any> {

  return this.httpClient.post(this.url+'/add',formationmetiers );
  }

  public  getAll(): Observable<FormationMetiers[]> {
    return this.httpClient.get<FormationMetiers[]>(this.url+'/get');
  }
 public update(formationmetiers:FormationMetiers): Observable<any> {

  return this.httpClient.put(this.url+'/update' ,formationmetiers);
  }
 public getformation(id): Observable<FormationMetiers[]> {
    return this.httpClient.get<FormationMetiers[]>(this.url + '/byid/' + id);
  }

   public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }
 public getformationBYintitule(intitule): Observable<FormationMetiers[]> {
    return this.httpClient.get<FormationMetiers[]>(this.url + '/byintitule/' + intitule);
  }
 public getformationBycategorie(categorie): Observable<FormationMetiers[]> {
    return this.httpClient.get<FormationMetiers[]>(this.url + '/bycategorie/' + categorie);
  }

public getformationBytype(type): Observable<FormationMetiers[]> {
    return this.httpClient.get<FormationMetiers[]>(this.url + '/bytype/' + type);
  }
public getformationByprix(prix): Observable<FormationMetiers[]> {
    return this.httpClient.get<FormationMetiers[]>(this.url + '/byprix/' + prix);
  }
   public get(id: number): Observable<any> {
    return this.httpClient.get(`${this.urldetails }/${id}`);
  }

}
