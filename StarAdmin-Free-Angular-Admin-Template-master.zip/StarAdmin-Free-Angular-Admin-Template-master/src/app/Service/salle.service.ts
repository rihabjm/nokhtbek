import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Salle} from '../Model/salle';
@Injectable({
  providedIn: 'root'
})
export class SalleService {
  constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/Salle';
 public save(salle:Salle): Observable<any> {

  return this.httpClient.post(this.url+'/add',salle );
  }

  public  getAll(): Observable<Salle[]> {
    return this.httpClient.get<Salle[]>(this.url+'/get');
  }
 public update(salle:Salle): Observable<any> {

  return this.httpClient.put(this.url+'/update' ,salle);
  }


public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }
}
