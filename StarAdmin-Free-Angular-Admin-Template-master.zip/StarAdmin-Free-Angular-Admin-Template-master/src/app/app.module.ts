import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule , Routes } from '@angular/router';
import { FormsModule ,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import {httpInterceptorProviders} from './Service/auth-interceptor';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from './app.component';
import { FormateurModule} from './Components/formateur/formateur.module';
import { FormationModule } from './Components/formation/formation.Module';
import {SalleModule} from './Components/salle/salle.module';
import { SessionModule} from './Components/session/session.Module';
import { LoginregistreModule } from './Components/loginregistre/loginregistre.Module';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { HttpClientModule } from '@angular/common/http';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AccplateformeComponent } from './accplateforme/accplateforme.component';
import { AcceuillComponent } from './acceuill/acceuill.component';


@NgModule({
  declarations: [
    AppComponent,

    AccplateformeComponent,
    AcceuillComponent,

  ],
  imports: [

    AppRoutingModule,
    BrowserModule,
    RouterModule,
    AppRoutingModule,
    FormsModule,
    NgbModule,
    FormateurModule,
    LoginregistreModule ,
     FormationModule,
    SessionModule,
    SalleModule,ReactiveFormsModule ,HttpClientModule ,
   TooltipModule.forRoot(),


  ],
  providers: [httpInterceptorProviders ],
  bootstrap: [AppComponent]
})
export class AppModule { }
